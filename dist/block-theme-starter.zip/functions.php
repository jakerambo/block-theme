<?php
/**
 * Import Theme Functions
 *
 * @package block-theme-starter
 * @since   1.0.0
 */

// Enqueue Scripts.
require_once 'functions/class-enqueue.php';
