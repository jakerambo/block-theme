"use strict";(self.webpackChunkblock_theme_starter=self.webpackChunkblock_theme_starter||[]).push([[2],{135:(e,t,s)=>{s.r(t),s.d(t,{test:()=>r});var r="Test!"}}]);
//# sourceMappingURL=test.js.map